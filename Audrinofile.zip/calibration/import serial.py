import serial
import numpy as np
import pyqtgraph as pg
from pyqtgraph.Qt import QtCore

# ── SERIAL ───────────────────────────────────────────────────────────────────
PORT    = '/dev/cu.usbmodem141403'
BAUD    = 115200
ser     = serial.Serial(PORT, BAUD, timeout=0.1)

# ── DATA BUFFER ───────────────────────────────────────────────────────────────
pts = np.empty((0,2), float)   # start empty, will grow forever

# ── QTGRAPH WINDOW ───────────────────────────────────────────────────────────
app = pg.mkQApp("Mag X–Y Trace")
win = pg.GraphicsLayoutWidget(show=True, title="Live Mag X–Y Trace")
plot = win.addPlot()
plot.setLabel('bottom', 'X (µT)')
plot.setLabel('left',   'Y (µT)')
plot.setXRange(-100, 100)
plot.setYRange(-100, 100)
plot.setAspectLocked(True)

# instead of a scatter, draw a line (so it stays on forever)
curve = plot.plot(pen=pg.mkPen('w', width=2))

# ── UPDATE FUNCTION ──────────────────────────────────────────────────────────
def update():
    global pts
    line = ser.readline().decode('ascii', errors='ignore').strip()
    if not line:
        return
    try:
        x_str, y_str = line.split(',',1)
        x, y = float(x_str), float(y_str)
    except ValueError:
        return

    # append (no trimming)
    pts = np.vstack([pts, (x,y)])

    # redraw entire path
    curve.setData(pts[:,0], pts[:,1])

# ── TIMER FOR ~100 Hz UPDATES ────────────────────────────────────────────────
timer = QtCore.QTimer()
timer.timeout.connect(update)
timer.start(10)   # 10 ms → 100 Hz

if __name__ == '__main__':
    pg.exec()
